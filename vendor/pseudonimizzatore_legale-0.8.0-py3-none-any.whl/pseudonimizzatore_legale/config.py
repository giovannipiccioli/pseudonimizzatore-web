"""Options for a pseudonymization run.

Output policy and the few detector/runtime switches live here. Legal decisions all use
the same detector pipeline; there are no court- or document-type routers.

The default person policy redacts detected identities across document types.
Public bodies and procedural references are kept, companies are opt-in, and tag
consistency is scoped to one document.
"""
from dataclasses import dataclass
from typing import Literal

from .labels import ROLE_PREFIXES, role_key


CompanyPolicy = bool | Literal["person_named"]

#: There is one document-agnostic legal pipeline. ``query`` only omits block scanning
#: for short interactive input. The two old names remain inexpensive compatibility
#: aliases; they do not route to court-specific implementations.
PROFILES = ("legal", "query", "cassazione", "generic")
_PROFILE_ALIASES = {"cassazione": "legal", "generic": "legal"}


@dataclass(frozen=True)
class Config:
    """Policy for one pseudonymization run.

    profile
        ``"legal"`` (default) runs the same source-agnostic legal pipeline on every
        decision. ``"query"`` only omits long block scanning for short interactive
        input. Legacy values ``"cassazione"`` and ``"generic"`` are accepted as aliases
        of ``"legal"`` and do not select different court logic.
    companies
        Control whether private companies become ``Società_N``. ``False`` (the
        default) keeps them. ``"person_named"`` replaces only names with a strong
        personal-name signal: an explicit family marker such as ``F.lli`` or
        ``Fratelli``, or two surname-shaped words joined by ``e`` or ``&``.
        ``True`` replaces every detected private company. Public bodies are never
        pseudonymized regardless of this option.
    roles
        ``False`` (the default) tags every person ``Nominativo_N``. ``True`` names the
        detected role instead: ``Ricorrente_N``, ``Resistente_N``, ``Difensore_N``.
        Detection is identical either way, and the report keeps the role.
    keep_roles
        Person roles whose full names may stay visible. Empty by default. Use
        ``("giudice",)`` for published judgments. Explicit per-person decisions
        can override this setting.
    keep_case_numbers
        Keep procedural identifiers (``n. 274/2023``, ``R.G. 17382/2023``, ECLI) and the
        name a European case is cited by (``C-348/16, Sacko``, ``Scoppola c. Italia``). On
        by default: pseudonymizing them makes the
        output uncitable and unlinkable to any other database. Switching it off does
        not pseudonymize case numbers; it only removes their explicit keep decision.
    sanitize
        Run the normalisation pre-pass (NFKC, zero-width strip, de-hyphenation, entity
        decode, HTML-tag and markdown flattening). Needed for ``.md`` input and for
        anything converted from PDF, OCR or HTML; ``<<…>>`` quotation marks are kept as
        text. Costs roughly 15% of runtime, and **changes offsets**
        — turn it off only if you need the original bytes preserved exactly, and accept
        the lower recall that comes with it.
    min_token_len
        Shortest token that may propagate a name through the document. Below 4
        characters the false-positive risk outweighs the recall gain.
    first_names
        Use the bundled list of first names registered in Italy as a weak additional
        person signal.
        A listed word seeds a person only next to a distinct, name-shaped token, never
        inside a street, saint's or town name, and the resulting full name still passes
        the ordinary institution, company and propagation guards. It is removed on its
        own only as the first name of a person already detected, matched
        case-sensitively, or after a salutation or kinship cue ("Caro Paolo,", "il
        figlio minore Tommaso"). Enabled by default because it materially improves
        recall without adding a model or runtime dependency.
    initials
        Replace the initials some sources write in place of a name ("A.G. e S.I. hanno
        impugnato"). ``False`` (the default) leaves them, as before. ``True`` takes them
        behind the cues that seed a name (``proposto da``, ``nei confronti di``, ``avv.``,
        ``nato a``…) and the same letters wherever else they recur. ``"all"`` is for a
        source known to write its parties that way: any initials that nothing excludes
        are a person. Sigle (``P.Q.M.``, ``D.L.``) and references (``art. 2697 C.C.``)
        stay under both; ``"all"`` on text that merely contains sigle, such as tax
        judgments, turns some of them into parties.
    ner
        Hugging Face model id of a token-classification model, a tuple of model ids to
        union for recall-first use, or ``None`` (default) to run regex-only. When set,
        each model becomes an **additional seed source**: it finds people the layout
        does not announce, and the same institution guards, conservative bare-token
        propagation, late policy and span resolution apply.

        Costs tens of times the regex runtime in the bundled benchmark, which is why it
        is opt-in. Requires ``pip install
        "pseudonimizzatore-legale[ner]"``. See `pseudonimizzatore_legale.ner` for what it does and does not
        buy, and the README for measured numbers.
    ner_threshold
        Minimum model confidence for a mention to become a seed. Below ~0.5 ordinary
        capitalised words start arriving; above ~0.8 genuine names in unusual layouts
        drop out.
    ner_device
        ``None`` (default) picks Apple MPS when available, else CPU. Pass ``"cpu"``,
        ``"mps"``, ``"cuda"`` or a device index to override. **Set this to ``"cpu"``
        for multi-worker batch runs** — several processes contending for one GPU is
        slower than letting each use its own core.
    verify
        Run review-oriented residual checks after rewriting. On by default. These checks do
        not modify output; they set ``Report.status`` to ``"needs_review"`` when a
        structured identifier, strongly cued person or known alias remains.

    Note there is no ``keep_places`` flag: a town is replaced only in a biographic slot
    (``nato a Stia``, ``residente a Pratovecchio``), when ISTAT lists it as a comune or,
    for a birthplace, its country follows in brackets; every other place name survives. Addresses are removed too, but they are
    anchored on a personal cue (``residente``, ``domiciliato``, ``con studio in``,
    ``sito in``) or on an address line of a private letterhead, signature or addressee
    block, never on the place name.
    """

    profile: str = "legal"
    companies: CompanyPolicy = False
    roles: bool = False
    keep_roles: tuple[str, ...] = ()
    keep_case_numbers: bool = True
    sanitize: bool = True
    min_token_len: int = 4
    first_names: bool = True
    initials: bool | Literal["all"] = False
    ner: str | tuple[str, ...] | None = None
    ner_threshold: float = 0.60
    ner_device: str | None = None
    verify: bool = True

    def __post_init__(self) -> None:
        roles = (self.keep_roles,) if isinstance(self.keep_roles, str) else self.keep_roles
        roles = tuple(dict.fromkeys(role_key(role) for role in roles))
        for role in roles:
            if role not in ROLE_PREFIXES:
                raise ValueError(f"unknown person role in keep_roles: {role!r}")
        object.__setattr__(self, "keep_roles", roles)
        if self.profile not in PROFILES:
            raise ValueError(
                f"unknown profile {self.profile!r}; expected one of {PROFILES}")
        if self.profile in _PROFILE_ALIASES:
            object.__setattr__(self, "profile", _PROFILE_ALIASES[self.profile])
        if not isinstance(self.companies, bool) and self.companies != "person_named":
            raise ValueError("companies must be False, 'person_named', or True")
        if not isinstance(self.initials, bool) and self.initials != "all":
            raise ValueError("initials must be False, True, or 'all'")
        if isinstance(self.ner, tuple) and not self.ner:
            raise ValueError("ner model tuple must not be empty")
